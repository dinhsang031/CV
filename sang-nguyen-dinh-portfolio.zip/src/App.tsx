import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Linkedin, 
  Github, 
  Mail, 
  Phone, 
  MapPin, 
  ExternalLink, 
  ChevronRight, 
  Download,
  Menu,
  X,
  Globe
} from 'lucide-react';
import { portfolioData } from './constants';

export default function App() {
  const [lang, setLang] = useState<'vi' | 'en'>('en');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const data = portfolioData[lang];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLang = () => setLang(prev => prev === 'vi' ? 'en' : 'vi');

  return (
    <div className="min-h-screen bg-brand-black text-brand-cream selection:bg-brand-gold selection:text-brand-black">
      {/* Navigation */}
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 md:px-12 py-4 flex justify-between items-center ${
          scrolled ? 'bg-brand-black/90 backdrop-blur-md border-b border-brand-gold/20' : 'bg-transparent'
        }`}
      >
        <div className="text-2xl font-serif font-bold tracking-tighter gold-text-gradient">
          S.N.D.
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8 text-xs font-medium tracking-widest uppercase">
          <a href="#work" className="hover:text-brand-gold transition-colors">{data.nav.work}</a>
          <a href="#about" className="hover:text-brand-gold transition-colors">{data.nav.about}</a>
          <a href="#experience" className="hover:text-brand-gold transition-colors">{data.experience.title}</a>
          <a href="#contact" className="hover:text-brand-gold transition-colors">{data.nav.contact}</a>
          
          <button 
            onClick={toggleLang}
            className="flex items-center space-x-2 hover:text-brand-gold transition-colors border border-brand-gold/30 px-3 py-1 rounded-full"
          >
            <Globe className="w-3 h-3" />
            <span>{lang === 'vi' ? 'EN' : 'VI'}</span>
          </button>

          <a 
            href="#contact" 
            className="gold-gradient text-brand-black px-6 py-2 rounded-sm font-bold hover:opacity-90 transition-opacity"
          >
            {data.nav.letsTalk}
          </a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-brand-gold" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-brand-black flex flex-col items-center justify-center space-y-8 text-xl font-serif"
          >
            <a href="#work" onClick={() => setIsMenuOpen(false)}>{data.nav.work}</a>
            <a href="#about" onClick={() => setIsMenuOpen(false)}>{data.nav.about}</a>
            <a href="#experience" onClick={() => setIsMenuOpen(false)}>{data.experience.title}</a>
            <a href="#contact" onClick={() => setIsMenuOpen(false)}>{data.nav.contact}</a>
            <button 
              onClick={() => { toggleLang(); setIsMenuOpen(false); }}
              className="flex items-center space-x-2 text-brand-gold"
            >
              <Globe className="w-5 h-5" />
              <span>{lang === 'vi' ? 'English' : 'Tiếng Việt'}</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col md:flex-row overflow-hidden pt-20 md:pt-0">
        {/* Left Side: Image */}
        <div className="w-full md:w-1/2 h-[50vh] md:h-screen relative bg-brand-dark-grey overflow-hidden">
          <img 
            src="/avatar.png" 
            alt="Sang Nguyen Dinh" 
            className="w-full h-full object-cover scale-125 transition-all duration-1000"
            style={{ objectPosition: 'center 20%' }}
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-black/40 via-transparent to-transparent"></div>
        </div>

        {/* Right Side: Content */}
        <div className="w-full md:w-1/2 min-h-[50vh] md:h-screen flex flex-col justify-center px-8 md:px-16 py-12 bg-brand-black">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-serif leading-tight mb-4 gold-text-gradient whitespace-nowrap">
              {data.heroHeadline}
            </h1>
            <p className="text-xs md:text-sm font-medium tracking-[0.4em] text-brand-gold uppercase mb-10 opacity-80">
              {data.heroSubtext}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#work" 
                className="gold-gradient text-brand-black px-8 py-4 rounded-sm font-bold text-center hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                {lang === 'vi' ? 'XEM CÔNG VIỆC' : 'VIEW SELECTED WORK'}
                <ChevronRight className="w-4 h-4" />
              </a>
              <a 
                href="https://drive.google.com/uc?export=download&id=1JmUD6vx8ub9H5k5ZLLrdBzPTMEyQ30Mk" 
                target="_blank"
                rel="noopener noreferrer"
                className="border border-brand-gold/50 text-brand-gold px-8 py-4 rounded-sm font-bold text-center hover:bg-brand-gold/10 transition-all flex items-center justify-center gap-2"
              >
                {lang === 'vi' ? 'TẢI CV' : 'DOWNLOAD RESUME'}
                <Download className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Summary Section */}
      <section id="about" className="py-24 px-6 md:px-12 border-y border-brand-gold/10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xs font-medium tracking-[0.3em] text-brand-gold uppercase mb-12">{data.summary.title}</h2>
          <p className="text-2xl md:text-4xl font-serif leading-snug text-brand-cream/90">
            {data.summary.content}
          </p>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-24 px-6 md:px-12 bg-brand-dark-grey/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-xs font-medium tracking-[0.3em] text-brand-gold uppercase mb-16">{data.experience.title}</h2>
          
          <div className="space-y-20">
            {data.experience.items.map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="grid md:grid-cols-3 gap-8"
              >
                <div className="md:col-span-1">
                  <p className="text-sm font-medium text-brand-gold/60 mb-2">{item.duration}</p>
                  <h3 className="text-2xl font-serif">{item.company}</h3>
                  <p className="text-brand-gold text-sm mt-1">{item.role}</p>
                </div>
                <div className="md:col-span-2">
                  <ul className="space-y-4 text-brand-cream/70 leading-relaxed">
                    {item.points.map((point, pIdx) => (
                      <li key={pIdx} className="flex gap-3">
                        <span className="text-brand-gold mt-1.5">•</span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="work" className="py-24 px-6 md:px-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-xs font-medium tracking-[0.3em] text-brand-gold uppercase mb-16">{data.projects.title}</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {data.projects.items.map((project, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ y: -10 }}
                className="group bg-brand-dark-grey p-8 border border-brand-gold/10 hover:border-brand-gold/40 transition-all flex flex-col h-full"
              >
                <div className="flex-grow">
                  <h3 className="text-xl font-serif mb-4 group-hover:text-brand-gold transition-colors">{project.title}</h3>
                  <p className="text-brand-cream/60 text-sm leading-relaxed mb-6">
                    {project.description}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2 mt-auto">
                  {project.tags.map((tag, tIdx) => (
                    <span key={tIdx} className="text-[10px] font-bold tracking-widest uppercase border border-brand-gold/20 px-2 py-1 rounded-sm text-brand-gold/80">
                      {tag}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-24 px-6 md:px-12 bg-brand-dark-grey/30 border-y border-brand-gold/10">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-xs font-medium tracking-[0.3em] text-brand-gold uppercase mb-12">{data.skills.title}</h2>
            <div className="flex flex-wrap gap-4">
              {data.skills.key.map((skill, idx) => (
                <span key={idx} className="text-lg font-serif italic text-brand-cream/80">
                  {skill}{idx < data.skills.key.length - 1 ? " / " : ""}
                </span>
              ))}
            </div>
          </div>
          <div>
            <h2 className="text-xs font-medium tracking-[0.3em] text-brand-gold uppercase mb-12">{lang === 'vi' ? 'KỸ THUẬT' : 'TECHNICAL'}</h2>
            <div className="grid grid-cols-2 gap-4">
              {data.skills.technical.map((skill, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm text-brand-cream/60">
                  <div className="w-1 h-1 bg-brand-gold rounded-full"></div>
                  {skill}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 px-6 md:px-12 text-center">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl md:text-8xl font-serif mb-8 gold-text-gradient">
              {data.contact.title}
            </h2>
            <p className="text-xl text-brand-cream/60 mb-12">
              {data.contact.subtext}
            </p>
            
            <div className="flex flex-col md:flex-row justify-center items-center gap-8 text-brand-gold font-medium tracking-widest uppercase text-xs">
              <a href={`mailto:${data.contact.email}`} className="flex items-center gap-2 hover:text-brand-cream transition-colors">
                <Mail className="w-4 h-4" />
                {data.contact.email}
              </a>
              <a href={`tel:${data.contact.phone}`} className="flex items-center gap-2 hover:text-brand-cream transition-colors">
                <Phone className="w-4 h-4" />
                {data.contact.phone}
              </a>
              <span className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                {data.contact.location}
              </span>
            </div>

            <div className="mt-16 flex justify-center gap-6">
              <a href="https://www.linkedin.com/in/sang-nguyen-dinh-234790231" target="_blank" className="p-4 border border-brand-gold/20 rounded-full hover:bg-brand-gold hover:text-brand-black transition-all">
                <Linkedin className="w-6 h-6" />
              </a>
              <a href="https://github.com/dinhsang031" target="_blank" className="p-4 border border-brand-gold/20 rounded-full hover:bg-brand-gold hover:text-brand-black transition-all">
                <Github className="w-6 h-6" />
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 md:px-12 border-t border-brand-gold/10 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] font-bold tracking-[0.2em] text-brand-cream/40 uppercase">
        <div className="flex items-center gap-2">
          <span>{data.name} Portfolio</span>
          <span className="text-brand-gold/20">|</span>
          <span>© 2024. All Rights Reserved.</span>
        </div>
        <div className="flex gap-8">
          <a href="https://www.linkedin.com/in/sang-nguyen-dinh-234790231" target="_blank" className="hover:text-brand-gold transition-colors">LinkedIn</a>
          <a href="https://github.com/dinhsang031" target="_blank" className="hover:text-brand-gold transition-colors">GitHub</a>
          <a href="#" className="hover:text-brand-gold transition-colors">X</a>
        </div>
      </footer>
    </div>
  );
}
