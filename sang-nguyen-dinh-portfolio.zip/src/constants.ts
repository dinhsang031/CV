export const portfolioData = {
  vi: {
    name: "Sang Nguyen Dinh",
    role: "Data Analyst | People Cost Budgeting & HR Analytics | AI & Automation Enthusiast",
    heroHeadline: "Sang Nguyen Dinh",
    heroSubtext: "Data Analyst | Workforce Budgeting & HR Analytics | AI & Automation Enthusiast",
    techStack: "DAX, Power Query, Data Automation, ML & Quản lý Dự án.",
    nav: {
      work: "CÔNG VIỆC",
      about: "GIỚI THIỆU",
      journal: "NHẬT KÝ",
      contact: "LIÊN HỆ",
      letsTalk: "HÃY TRÒ CHUYỆN"
    },
    summary: {
      title: "TÓM TẮT",
      content: "Hiện đang làm việc tại Central Retail, tôi quản lý Hệ sinh thái Dữ liệu Nhân sự cho danh mục đa dạng gồm hơn 10 thương hiệu toàn cầu (Dyson, Under Armour, HOKA, Supersports, Crocs, Fitflop...) tại hơn 150 cửa hàng trên toàn quốc. Tôi tận dụng sự hiểu biết sâu sắc về quy trình nhân sự để xây dựng các mô hình dữ liệu tự động và báo cáo tài chính. Sứ mệnh của tôi là chuyển đổi dữ liệu nhân sự phức tạp thành các insight tài chính hành động, giúp tổ chức tối ưu hóa Chi phí Nhân sự và cải thiện hiệu quả vận hành."
    },
    experience: {
      title: "KINH NGHIỆM LÀM VIỆC",
      items: [
        {
          company: "CENTRAL RETAIL",
          role: "Data Analyst",
          duration: "Tháng 8/2025 - Hiện tại",
          location: "Hồ Chí Minh, Việt Nam",
          points: [
            "Quản lý Dữ liệu: Chuẩn hóa các nguồn dữ liệu rời rạc từ nhiều Đơn vị Kinh doanh thành Mô hình Dữ liệu 4 Lớp thống nhất.",
            "Hoạch định Tài chính & Tối ưu Chi phí: Dẫn dắt việc tự động hóa Chi phí Nhân sự & Ngân sách Hàng năm, hỗ trợ kiểm soát ngân sách lao động hàng triệu đô la.",
            "Phân tích Chiến lược & Insights: Chuyển đổi dữ liệu nhân sự phức tạp thành các insight kinh doanh hành động.",
            "BI, Tự động hóa & AI: Xây dựng các pipeline tự động end-to-end sử dụng M & DAX, giảm chu kỳ báo cáo 90%.",
            "Quản trị & Chiến lược Dữ liệu: Đóng vai trò 'người gác cổng' cho chất lượng Dữ liệu Chủ (Master Data) HR."
          ]
        },
        {
          company: "KIM TIN GROUP",
          role: "Data Analyst",
          duration: "Tháng 8/2023 - Tháng 8/2025",
          location: "Hồ Chí Minh, Việt Nam",
          points: [
            "Dashboard Design: Phát triển các dashboard HR toàn diện sử dụng Power BI cho Tuyển dụng, Lương, Phúc lợi và Đào tạo.",
            "Phân tích Ad-Hoc: Áp dụng Python để phân tích ad-hoc động và phát triển mô hình học máy.",
            "Phát triển Giải pháp Dữ liệu: Phát triển các giải pháp dữ liệu tích hợp sử dụng App Sheet, App Script, Forms, n8n.",
            "Tích hợp Dữ liệu: Hợp nhất dữ liệu HR từ nhiều nguồn khác nhau vào một cơ sở dữ liệu tập trung."
          ]
        }
      ]
    },
    projects: {
      title: "DỰ ÁN NỔI BẬT",
      items: [
        {
          title: "HR Dashboards cho Tập đoàn 20 công ty con",
          description: "Thiết kế và triển khai các HR dashboard toàn diện bao gồm Tuyển dụng, Lương thưởng, Phúc lợi & Đào tạo.",
          tags: ["Power BI", "SQL", "Data Viz"]
        },
        {
          title: "Mô hình Dự đoán Tỷ lệ nghỉ việc",
          description: "Phát triển mô hình Machine Learning để dự đoán tỷ lệ nghỉ việc và xác định các lý do chính gây ra sự biến động.",
          tags: ["Machine Learning", "Python", "Predictive Analytics"]
        },
        {
          title: "Hệ thống Sàng lọc CV bằng AI",
          description: "Phát triển hệ thống AI tự động trích xuất CV và phân tích ứng viên theo yêu cầu công việc.",
          tags: ["AI", "Automation", "Python", "n8n"]
        }
      ]
    },
    skills: {
      title: "KỸ NĂNG",
      key: ["Trực quan hóa dữ liệu", "Thao tác dữ liệu", "Thuyết trình", "Giao tiếp cá nhân", "Nghiên cứu", "Quản lý dự án", "Kể chuyện bằng Dữ liệu", "Tư duy Phân tích"],
      technical: ["Power BI", "Postgre SQL", "Python", "AppSheet", "Machine Learning", "Excel, GG Sheet", "Thống kê", "AI & Tự động hóa"]
    },
    education: {
      title: "HỌC VẤN",
      degree: "Cử nhân Quản trị Dịch vụ Du lịch và Lữ hành",
      university: "Đại học Kinh tế - Đại học Đà Nẵng",
      duration: "Tháng 10/2012 - Tháng 1/2017"
    },
    contact: {
      title: "LIÊN HỆ VỚI TÔI",
      subtext: "Tôi luôn sẵn lòng kết nối và khám phá những cơ hội mới!",
      email: "dinhsang031@gmail.com",
      phone: "+84935764976",
      location: "Hồ Chí Minh, Việt Nam"
    }
  },
  en: {
    name: "Sang Nguyen Dinh",
    role: "Data Analyst | People Cost Budgeting & HR Analytics | AI & Automation Enthusiast",
    heroHeadline: "Sang Nguyen Dinh",
    heroSubtext: "Data Analyst | Workforce Budgeting & HR Analytics | AI & Automation Enthusiast",
    techStack: "DAX, Power Query, Data Automation, ML & Project Management",
    nav: {
      work: "WORK",
      about: "ABOUT",
      journal: "JOURNAL",
      contact: "CONTACT",
      letsTalk: "LET'S TALK"
    },
    summary: {
      title: "SUMMARY",
      content: "Currently working at Central Retail, I managing the HR Data Ecosystem for a diverse portfolio of 10+ global brands (including Dyson, Under Armour, HOKA, Supersports, Crocs, Fitflop) across 150+ stores nationwide and leverage my deep understanding of HR processes to build automated data models and financial reports. My mission is to translate complex HR data into actionable financial insights, helping organizations optimize People Cost and improve operational efficiency."
    },
    experience: {
      title: "WORK EXPERIENCE",
      items: [
        {
          company: "CENTRAL RETAIL",
          role: "Data Analyst",
          duration: "Aug, 2025 - Current",
          location: "Ho Chi Minh City, Vietnam",
          points: [
            "Data Management: Standardized disparate data sources from various Business Units into a unified 4-Layer Data Model.",
            "Financial Planning & Cost Optimization: Leading the automation of People Cost & Annual Budgeting, supporting the Business Controller and HR Director.",
            "Strategic Analytics & Insights: Translated complex HR data into actionable business insights.",
            "BI, Automation & AI: Engineered end-to-end automated pipelines using M & DAX, reducing reporting cycle time by 90%.",
            "Data Governance & Strategy: Acting as the gatekeeper for HR Master Data quality."
          ]
        },
        {
          company: "KIM TIN GROUP",
          role: "Data Analyst",
          duration: "Aug, 2023 - Aug, 2025",
          location: "Ho Chi Minh City, Vietnam",
          points: [
            "Dashboard Design: Developed comprehensive HR dashboards using Power BI for Recruitment, Payroll, Benefits, and Training.",
            "Ad-Hoc Analysis: Applied Python for dynamic ad-hoc analyses and developed Machine learning models.",
            "Data Solutions Development: Developed integrated data solutions using App Sheet, App Script, Forms, n8n.",
            "Data Integration: Consolidated HR data from various sources into a centralized database."
          ]
        }
      ]
    },
    projects: {
      title: "KEY PROJECTS",
      items: [
        {
          title: "HR Dashboards for Group of 20 Subsidiaries",
          description: "Designed and implemented comprehensive HR dashboards covering Recruitment, Payroll, Benefit & Training data.",
          tags: ["Power BI", "SQL", "Data Viz"]
        },
        {
          title: "Employee Turnover Prediction Model",
          description: "Developed a Machine Learning model to predict employee turnover and identify key reasons for attrition.",
          tags: ["Machine Learning", "Python", "Predictive Analytics"]
        },
        {
          title: "AI CV Screening System",
          description: "Developed an AI system to automate CV extraction and candidate analysis against job requirements.",
          tags: ["AI", "Automation", "Python", "n8n"]
        }
      ]
    },
    skills: {
      title: "SKILLS",
      key: ["Data Visualization", "Data Manipulation", "Presentation", "Interpersonal", "Research", "Project Management", "Storytelling with Data", "Analytical Thinking"],
      technical: ["Power BI", "Postgre SQL", "Python", "AppSheet", "Machine Learning", "Excel, GG Sheet", "Statistics", "AI & Automation"]
    },
    education: {
      title: "EDUCATION",
      degree: "Bachelor's Degree, Tourism and Travel Services Management",
      university: "University of Economics - The University of Danang",
      duration: "October 2012 - January 2017"
    },
    contact: {
      title: "CONTACT ME",
      subtext: "I'm always open to connecting and exploring new opportunities!",
      email: "dinhsang031@gmail.com",
      phone: "+84935764976",
      location: "Ho Chi Minh City, Vietnam"
    }
  }
};
